"""Judge agent for automated correctness classification."""

