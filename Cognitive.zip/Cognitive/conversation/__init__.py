"""Core conversation system."""

