"""
Utilities for storing debate results in a structured format.
"""
import os
import json
from datetime import datetime
from typing import Dict, Any, Optional


def _extract_agent_final_stances(conversation_result: Dict[str, Any]) -> Dict[str, Any]:
    """Extract the final stance information for each agent."""
    summary = {}
    stance_summary = conversation_result.get("stance_summary", {})
    per_agent = stance_summary.get("per_agent", {})
    for agent, info in per_agent.items():
        summary[agent] = {
            "initial_stance": info.get("initial"),
            "final_stance": info.get("final"),
            "positive_turns": info.get("positive_turns", 0),
            "negative_turns": info.get("negative_turns", 0),
            "neutral_turns": info.get("neutral_turns", 0),
        }
    return summary


def _extract_judge_summary(evaluation: Dict[str, Any]) -> Dict[str, Any]:
    """Clean judge evaluation data."""
    if not evaluation:
        return {}
    return {
        "overall_correctness": evaluation.get("overall_correctness", "unknown"),
        "converged": evaluation.get("converged", False),
        "hallucinations_detected": evaluation.get("hallucinations_detected", False),
        "agent_evaluations": evaluation.get("agent_evaluations", {}),
        "reasoning": evaluation.get("raw_evaluation"),
    }


def build_debate_summary(
    conversation_result: Dict[str, Any],
    evaluation: Dict[str, Any],
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a structured summary of a debate."""
    metadata = metadata or {}
    summary = {
        "claim": conversation_result.get("claim"),
        "claim_type": conversation_result.get("claim_type"),
        "agents": conversation_result.get("personalities", []),
        "parameters": {
            "model": conversation_result.get("model"),
            "temperature": conversation_result.get("temperature"),
            "max_turns": conversation_result.get("max_turns"),
            "context_size": conversation_result.get("context_size"),
        },
        "conversation_metrics": {
            "num_turns": conversation_result.get("num_turns"),
            "duration_seconds": conversation_result.get("duration_seconds"),
        },
        "final_responses": conversation_result.get("final_responses", {}),
        "agent_stances": _extract_agent_final_stances(conversation_result),
        "stance_over_time": conversation_result.get("stance_summary", {}).get("turns", []),
        "judge_evaluation": _extract_judge_summary(evaluation),
        "metadata": metadata,
    }
    return summary


def save_debate_summary(
    conversation_result: Dict[str, Any],
    evaluation: Dict[str, Any],
    timestamp: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Save debate summary to results/debates directory.

    Returns:
        Path to the saved summary file.
    """
    summary = build_debate_summary(conversation_result, evaluation, metadata=metadata)

    timestamp = timestamp or datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join("results", "debates")
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, f"debate_summary_{timestamp}.json")

    with open(path, "w") as f:
        json.dump(summary, f, indent=2)

    return path


