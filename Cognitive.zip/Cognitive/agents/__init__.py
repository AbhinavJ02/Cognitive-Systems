"""Agent personality definitions and factory."""

