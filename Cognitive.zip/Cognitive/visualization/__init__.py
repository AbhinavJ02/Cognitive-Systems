"""Visualization tools for stance shifts and accuracy."""

